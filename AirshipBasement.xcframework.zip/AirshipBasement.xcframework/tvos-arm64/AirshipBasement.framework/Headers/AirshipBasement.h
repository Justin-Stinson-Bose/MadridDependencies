/* Copyright Airship and Contributors */

#if !defined(UA_USE_MODULE_IMPORT)
#define UA_USE_MODULE_IMPORT 1
#endif

#import <UIKit/UIKit.h>

//! Project version number for AirshipCore.
FOUNDATION_EXPORT double AirshipBasementVersionNumber;

//! Project version string for AirshipCore.
FOUNDATION_EXPORT const unsigned char AirshipBasementVersionString[];

#import "AirshipBasementLib.h"
#include<zlib.h>
