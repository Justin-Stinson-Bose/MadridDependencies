/* Copyright Airship and Contributors */

#import <UIKit/UIKit.h>

//! Project version number for AirshipNotificationServiceExtension.
FOUNDATION_EXPORT double AirshipNotificationServiceExtensionVersionNumber;

//! Project version string for AirshipNotificationServiceExtension.
FOUNDATION_EXPORT const unsigned char AirshipNotificationServiceExtensionVersionString[];

#import "UANotificationServiceExtension.h"
#import "UAMediaAttachmentPayload.h"
