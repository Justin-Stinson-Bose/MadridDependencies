/* Copyright Airship and Contributors */
#if __has_include("AirshipBasement/AirshipBasement.h")
#import <AirshipBasement/AirshipBasement.h>
#else
#import "AirshipBasementLib.h"
#endif
