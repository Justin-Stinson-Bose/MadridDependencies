/* Copyright Airship and Contributors */
#if !defined(UA_USE_MODULE_IMPORT)
#define UA_USE_MODULE_IMPORT 1
#endif

#import <UIKit/UIKit.h>

//! Project version number for AirshipAutomation.
FOUNDATION_EXPORT double AirshipAutomationVersionNumber;

//! Project version string for AirshipAutomation.
FOUNDATION_EXPORT const unsigned char AirshipAutomationVersionString[];

#import "AirshipAutomationLib.h"
