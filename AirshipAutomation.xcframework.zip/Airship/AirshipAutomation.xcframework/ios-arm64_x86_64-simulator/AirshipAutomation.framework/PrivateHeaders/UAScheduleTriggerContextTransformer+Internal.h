
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UAScheduleTriggerContextTransformer : NSValueTransformer

@end

NS_ASSUME_NONNULL_END
